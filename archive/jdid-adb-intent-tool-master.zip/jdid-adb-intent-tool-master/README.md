# JDid adb intent tool
此工具通过Excel的vba宏，依赖adb来发送各类印尼项目中常用的intent。方便管理资源。目前仅支持windows，需要MacOS的可以自由拓展。

目前支持如下功能：
- 打开商详（自定sku/spu)
- 打开购物车（可自定sku）
- 打开搜索（可指定关键词）
- 打开内置Web页（自定url）
- 打开登录页
- 打开首页
- 打开个人中心
- 打开优惠券
- 打开Feed流
- 打开拍照购
- 自定义Deeplink入参启动页面

# 使用

1. 下载此工具。
2. 打开jdid-adb-intent.xlsm
3. 点击“启用宏/启用内容”，如果不小心错过，重新打开即可。
4. 在第一个sheet中，寻找自己需要启动的页面，输入需要的参数。确保adb设备已经连接且仅有一个设备。点击对应项的左侧Run按钮即可。若无响应，则打开JDid-app再尝试。

![screenshot](./screenshot/screenshot.jpg)

# 拓展

1. 打开Actions的工作sheet。
2. 添加新的Action或者修改已有的Action。
3. 返回第一个sheet，会自动刷新，运行你想要的action。

- 若需要查看代码，则点击视图Tab，点击"查看宏"，再点击“编辑宏”即可。

# 动机

- 首先说在前面，不建议学习VBA，语法非常陈旧、过时。
- 有的时候比如打开特定商品商详，不方便扫码也不方便加断点改skuId的时候，便想起用adb am intent来启动。但项目里的deeplink等intent接受方式较多，需要整理收集。而且对于已经输入的sku数据等可能需要多次使用，最好可以保留。另外，还希望整个运行、管理、拓展的过程要简单，不能太Hack。因此最终决定在Excel中实现这个工具。
- 此工具或许能帮助到任何不熟悉app，不熟悉android基本内容的研发或测试。

# Todo

1. 增加MacOS支持。