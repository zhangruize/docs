import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

/**
 * 在Gradle 配置完成时，会生成和Jdid组件化相关的依赖冲突报告。
 * 此工具是为了尽可能让所有组件使用统一版本的依赖，而避免不兼容的版本冲突引起 运行时崩溃。
 */
val reportFileName = "JdidDependenciesConflictReport.txt"
allprojects {
    afterEvaluate {
        clearReport()
        appendReport("请检查此报告中的组件化依赖冲突，尽可能使用统一的版本，并确保没有出现不兼容的版本覆盖，以此避免运行时崩溃。\n")
        appendReport("生成于${Date()}\n\n")
        project.configurations.forEach { configuration ->
            configuration.incoming.afterResolve {
                val results = HashMap<ResolvedComponentResult, MutableList<ResolvedDependencyResult>>()
                val skippedList = ArrayList<ResolvedComponentResult>()

                resolutionResult.allComponents.forEach { resolvedComponentResult ->
                    if (!resolvedComponentResult.selectionReason.isExpected) {
                        if (isInMonitorList(resolvedComponentResult)) {
                            resolvedComponentResult.dependents.forEach {
                                if (!it.requested.matchesStrictly(it.selected.id)) {
                                    results.putIfAbsent(it.from, ArrayList())
                                    results[it.from]!!.add(it)
                                }
                            }
                        } else {
                            skippedList.add(resolvedComponentResult)
                        }
                    }
                }

                if (results.isNotEmpty()) {
                    appendReport("Result for $configuration in $project\n")
                    for ((k, v) in results) {
                        appendReport("\t${k.moduleVersion?.name}:\n")
                        v.forEachIndexed { index, it ->
                            appendReport("\t\t${index + 1}. ${it.requested.displayName} \t-> ${it.selected.moduleVersion?.version}\n")
                        }
                    }
                    appendReport("\n")
                }
            }
        }
    }
}

fun isInMonitorList(resolvedComponentResult: ResolvedComponentResult?): Boolean {
    val checkRegexList = listOf(".*jdid.*", ".*cdyjy.*", ".*jd_id.*")
    checkRegexList.forEach {
        if (resolvedComponentResult?.moduleVersion?.group?.contains(Regex(it))!!) {
            return true
        }
    }
    return false
}

fun clearReport() {
    File(reportFileName).delete()
}

fun appendReport(str: String) {
    File(reportFileName).appendText(str)
}