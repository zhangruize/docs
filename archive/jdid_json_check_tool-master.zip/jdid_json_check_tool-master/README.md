[![pipeline status](http://git.jd.com/zhangruize/jdid_json_check_tool/badges/master/pipeline.svg)](http://git.jd.com/zhangruize/jdid_json_check_tool/commits/master)

windows运行方式
```
chcp 65001
python json_check_tool.py
```

mac运行方式
```
python json_check_tool.py
```

也可以Pycharm运行

需要依赖
```
jsonpath
Pillow
requests
```

checker: 接收整个首页的JsonDict，自定义整个json数据的检查过程，实现如：HomePageFloorChecker，解析Json数据以楼层维度进行检查。


model_checker: 接收单个楼层的JsonDict，由HomePageFloorChecker对每个楼层依次调用进行检查。


common: 提供info, warn, status打印信息方法。不要直接使用print。