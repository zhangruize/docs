# coding=utf-8
from abc import abstractmethod

import jsonpath

from common import warn
from model_checker import TitleInfoChecker, UrlInfoModelChecker, ImgInfoModelChecker


class Checker:
    def __init__(self):
        pass

    @abstractmethod
    def check(self, json_dict):
        pass


class HomePageFloorChecker(Checker):
    model_checker = {'defaultTitleModel': TitleInfoChecker(),
                     'imageSlider': TitleInfoChecker()
                     }
    any_model_checker = [ImgInfoModelChecker(), UrlInfoModelChecker()]

    def check(self, json_dict):
        floor_list = jsonpath.jsonpath(json_dict, "$.data.floorList")[0]
        for floor in floor_list:
            for checker in self.any_model_checker:
                checker.check_model(floor)
            if floor['type'] in self.model_checker:
                self.model_checker[floor['type']].check_model(floor)


class NullFieldChecker(Checker):
    def check(self, json_dict):
        if type(json_dict) is dict:
            for k, v in json_dict.items():
                self.check(v)

        elif type(json_dict) is list:
            if not json_dict or len(json_dict) == 0:
                warn('空列表, key: {}'.format(json_dict))
            else:
                for item in json_dict:
                    self.check(item)
