echo "123123" >> 123.txt
cat 123.txt