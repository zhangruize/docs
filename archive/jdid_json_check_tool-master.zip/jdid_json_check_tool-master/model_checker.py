# coding=utf-8
from abc import abstractmethod
from io import BytesIO

import jsonpath
import requests
from PIL import Image

from common import warn, status


class ModelChecker:
    def __init__(self):
        pass

    @abstractmethod
    def check_model(self, json_dict):
        pass


class ImgInfoModelChecker(ModelChecker):
    floor_img_default_ratio = {'category': 72.0 / 60}

    def check_model(self, json_dict):
        img_node_list = jsonpath.jsonpath(json_dict, "$..[?(@.imgUrl)]")
        if img_node_list:
            for img_node in img_node_list:
                url = img_node['imgUrl']
                status("Checking img {}".format(url))
                if not url.startswith("http"):
                    url = "https://img10.jd.id/Indonesia/" + url

                if not (url.endswith(".jpg") or url.endswith(".png") or url.endswith(".jpeg") or url.endswith(
                        ".png.dpg") or url.endswith(".gif")):
                    warn("图片格式不识别: {}".format(url))
                else:
                    if 'imgFloat' in img_node:
                        # check img ratio
                        try:
                            given_ratio = float(img_node['imgFloat'])
                            im = Image.open(BytesIO(requests.get(url).content))
                            width, height = im.size
                            ratio = width * 1.0 / height
                            floor_name = json_dict['type']
                            if floor_name in self.floor_img_default_ratio:
                                given_ratio = self.floor_img_default_ratio[floor_name]

                            if abs(ratio - given_ratio) > 0.01:
                                warn(
                                    "图片比例错误, 所属楼层: {}, 下发: {},{} 实际: {:f}, {:d} * {:d}, url: {}".format(
                                        floor_name, img_node['imgFloat'], '楼层默认图片比例: {}'.format(
                                            given_ratio) if floor_name in self.floor_img_default_ratio else '', ratio,
                                        width, height, url))
                        except IOError:
                            warn("图片加载失败: {}".format(url))


class UrlInfoModelChecker(ModelChecker):
    white_list = [x + y for x in ['http://', 'https://'] for y in ['www.jd.id', 'm.jd.id', 'campv.jd.id', 'sale.jd.id']]

    def check_model(self, json_dict):
        url_list = jsonpath.jsonpath(json_dict, "$..urlForType")
        if url_list:
            for url_info_node in url_list:
                if url_info_node['urlType'] == 1:
                    url = url_info_node['url']
                    status("Checking url {}".format(url))

                    is_in_white_list = False
                    for w in self.white_list:
                        if url.startswith(w):
                            is_in_white_list = True
                            break
                    if not is_in_white_list:
                        warn('{}{}, 所属楼层{}, 楼层名称: {}'.format("错误跳转链接: " if url else "空跳转链接", url,
                                                             json_dict['type'], json_dict['floorName']))


class TitleInfoChecker(ModelChecker):

    def check_model(self, json_dict):
        pass
