import datetime
import sys

last_status_len = 0
is_status_enable = True


def info(msg):
    msg = "\r[{}]\t{}".format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
    if is_status_enable:
        clear_line()
        print(msg)
        update_line_to_clear(msg)
    else:
        print(msg)


def warn(msg):
    msg = "\r[Warning]\t{}".format(msg)
    if is_status_enable:
        clear_line()
        print(msg)
        update_line_to_clear(msg)
    else:
        print(msg)


def status(msg):
    if is_status_enable:
        clear_line()
        msg = "\r> {}".format(msg)
        sys.stdout.write(msg)
        sys.stdout.flush()
        update_line_to_clear(msg)


def clear_line():
    clear_str = ''
    global last_status_len
    for i in range(last_status_len):
        clear_str += ' '
    sys.stdout.write("\r{}\r".format(clear_str))
    sys.stdout.flush()


def update_line_to_clear(msg):
    global last_status_len
    last_status_len = len(msg)


def disable_status():
    global is_status_enable
    is_status_enable = False
