# coding=utf-8
import datetime
import json
import sys

import requests

from checker import NullFieldChecker, HomePageFloorChecker
from common import status, info, disable_status


def get_target_url():
    return ["https://igate2.jd.id/hom/v2?code=appNewNormalHome", "https://igate2.jd.id/hom/v2?code=appPromoHome"]


def get_checkers():
    return [HomePageFloorChecker(), NullFieldChecker()]


def fetch_json(url, **kwargs):
    try_times = 0
    while try_times <= 3:
        try:
            status('Fetching json from: {}'.format(url))
            return requests.get(url, **kwargs).content
        except IOError:
            try_times = try_times + 1


def check_json(json_str, checkers):
    try:
        json_dict = json.loads(json_str)
        for checker in checkers:
            checker.check(json_dict)
    except ValueError as e:
        print("\r加载Json失败 {}\n{}".format(e, json_str))


def get_url_check_result(url):
    start = datetime.datetime.now()
    info("开始检查 {}".format(url))
    check_json(fetch_json(url), get_checkers())
    end = datetime.datetime.now()
    info("检查结束, 用时 {} 秒".format((end - start).seconds))


def main(argv):
    if '--silent' in argv:
        disable_status()
    for url in get_target_url():
        get_url_check_result(url)


if __name__ == '__main__':
    main(sys.argv[1:])
