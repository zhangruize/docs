#include <array>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <list>
#include <math.h> // smallpt, a Path Tracer by Kevin Beason, 2009
#include <memory>
#include <ostream>
#include <stdio.h>  //        Remove "-fopenmp" for g++ version < 4.2
#include <stdlib.h> // Make : g++ -O3 -fopenmp explicit.cpp -o explicit
int count = 0;
struct Vec {      // Usage: time ./explicit 16 && xv image.ppm
  double x, y, z; // position, also color (r,g,b)
  Vec(double x_ = 0, double y_ = 0, double z_ = 0) {
    x = x_;
    y = y_;
    z = z_;
  }
  Vec operator+(const Vec &b) const { return Vec(x + b.x, y + b.y, z + b.z); }
  Vec operator-(const Vec &b) const { return Vec(x - b.x, y - b.y, z - b.z); }
  Vec operator*(double b) const { return Vec(x * b, y * b, z * b); }
  Vec operator/(const Vec &b) const { return Vec(x / b.x, y / b.y, z / b.z); }
  Vec mult(const Vec &b) const { return Vec(x * b.x, y * b.y, z * b.z); }
  Vec &norm() { return *this = *this * (1 / sqrt(x * x + y * y + z * z)); }
  double dot(const Vec &b) const {
    return x * b.x + y * b.y + z * b.z;
  } // cross:
  Vec operator%(Vec &b) {
    return Vec(y * b.z - z * b.y, z * b.x - x * b.z, x * b.y - y * b.x);
  }
};
const int kNumPlaneSetNormals = 7;
const Vec planeSetNormals[kNumPlaneSetNormals] = {
    Vec(1, 0, 0),
    Vec(0, 1, 0),
    Vec(0, 0, 1),
    Vec(sqrtf(3) / 3.f, sqrtf(3) / 3.f, sqrtf(3) / 3.f),
    Vec(-sqrtf(3) / 3.f, sqrtf(3) / 3.f, sqrtf(3) / 3.f),
    Vec(-sqrtf(3) / 3.f, -sqrtf(3) / 3.f, sqrtf(3) / 3.f),
    Vec(sqrtf(3) / 3.f, -sqrtf(3) / 3.f, sqrtf(3) / 3.f)};
struct Ray {
  Ray(const Vec &orig, const Vec &dir) : o(orig), d(dir) {
    invdir = Vec(1. / dir.x, 1. / dir.y, 1. / dir.z);
    sign[0] = (invdir.x < 0);
    sign[1] = (invdir.y < 0);
    sign[2] = (invdir.z < 0);
    for (int i = 0; i < kNumPlaneSetNormals; ++i) {
      precomputedNumerator[i] = planeSetNormals[i].dot(o);
      precomputeDenominator[i] = planeSetNormals[i].dot(d);
    }
  }
  Vec o, d; // ray orig and dir
  Vec invdir;
  int sign[3];
  float precomputedNumerator[kNumPlaneSetNormals],
      precomputeDenominator[kNumPlaneSetNormals];
};
enum Refl_t { DIFF, SPEC, REFR }; // material types, used in radiance()
struct Triangle {
  Vec a, b, c, color, normal, e = Vec();
  Refl_t refl;
  Triangle(Vec a_ = Vec(), Vec b_ = Vec(), Vec c_ = Vec(), Vec color_ = Vec(),
           Refl_t refl_ = DIFF)
      : a(a_), b(b_), c(c_), color(color_), refl(refl_) {
    Vec ab = b - a, ac = c - a;
    normal = (ab % ac).norm();
  }

  bool intersect(Vec rayOrigin, Vec rayVector, double &t,
                 Vec &outIntersectionPoint) {
    count++;
    const double EPSILON = 0.0000001;
    Vec vertex0 = a;
    Vec vertex1 = b;
    Vec vertex2 = c;
    Vec edge1, edge2, h, s, q;
    double a, f, u, v;
    edge1 = vertex1 - vertex0;
    edge2 = vertex2 - vertex0;
    h = rayVector % edge2;
    a = edge1.dot(h);
    if (a > -EPSILON && a < EPSILON)
      return false; // This ray is parallel to this triangle.
    f = 1.0 / a;
    s = rayOrigin - vertex0;
    u = f * s.dot(h);
    if (u < 0.0 || u > 1.0)
      return false;
    q = s % edge1;
    v = f * rayVector.dot(q);
    if (v < 0.0 || u + v > 1.0)
      return false;
    // At this stage we can compute t to find out where the intersection point
    // is on the line.
    t = f * edge2.dot(q);
    if (t > EPSILON) // ray intersection
    {
      outIntersectionPoint = rayOrigin + rayVector * t;
      return true;
    } else // This means that there is a line intersection but not a ray
           // intersection.
      return false;
  }
};
struct Cubic {
  Vec v0, v1, v2, v3, v4, v5, v6, v7, color;
  Refl_t refl;
  Cubic(Vec pos, double w, double h, double z, Vec color_, Refl_t refl_)
      : color(color_), refl(refl_) {
    v0 = pos;
    v1 = Vec(pos.x + w, pos.y, pos.z);
    v2 = Vec(pos.x, pos.y + h, pos.z);
    v3 = Vec(pos.x + w, pos.y + h, pos.z);
    v4 = Vec(pos.x, pos.y, pos.z + z);
    v5 = Vec(pos.x + w, pos.y, pos.z + z);
    v6 = Vec(pos.x, pos.y + h, pos.z + z);
    v7 = Vec(pos.x + w, pos.y + h, pos.z + z);
  }
  void writeTriangles(std::list<Triangle> *list) {
    list->push_back(Triangle(v0, v1, v3, color, refl));
    list->push_back(Triangle(v0, v3, v2, color, refl));
    list->push_back(Triangle(v1, v5, v7, color, refl));
    list->push_back(Triangle(v1, v7, v3, color, refl));
    list->push_back(Triangle(v2, v3, v7, color, refl));
    list->push_back(Triangle(v2, v7, v6, color, refl));
    list->push_back(Triangle(v5, v4, v7, color, refl));
    list->push_back(Triangle(v7, v4, v6, color, refl));
    list->push_back(Triangle(v0, v6, v4, color, refl));
    list->push_back(Triangle(v2, v6, v0, color, refl));
    list->push_back(Triangle(v0, v4, v5, color, refl));
    list->push_back(Triangle(v0, v5, v1, color, refl));
  }
};
struct Sphere {
  double rad;  // radius
  Vec p, e, c; // position, emission, color
  Refl_t refl; // reflection type (DIFFuse, SPECular, REFRactive)
  Sphere(double rad_, Vec p_, Vec e_, Vec c_, Refl_t refl_)
      : rad(rad_), p(p_), e(e_), c(c_), refl(refl_) {}
  double intersect(const Ray &r) const { // returns distance, 0 if nohit
    Vec op = p - r.o; // Solve t^2*d.d + 2*t*(o-p).d + (o-p).(o-p)-R^2 = 0
    double t, eps = 1e-4, b = op.dot(r.d), det = b * b - op.dot(op) + rad * rad;
    if (det < 0)
      return 0;
    else
      det = sqrt(det);
    return (t = b - det) > eps ? t : ((t = b + det) > eps ? t : 0);
  }
};
class MeshObject {
public:
  std::shared_ptr<std::array<std::array<double, 2>, kNumPlaneSetNormals>> dis;
  std::list<Triangle> triangles;
  MeshObject()
      : dis(std::make_shared<
            std::array<std::array<double, 2>, kNumPlaneSetNormals>>(
            std::array<std::array<double, 2>, kNumPlaneSetNormals>())){};

  void computeBounds() {
    for (int i = 0; i < kNumPlaneSetNormals; i++) {
      Vec planeNormal = planeSetNormals[i];
      dis.get()[0][i][0] = 1e20;
      dis.get()[0][i][1] = -1e20;
      double d;
      for (Triangle tri : triangles) {
        Vec vs[] = {tri.a, tri.b, tri.c};
        for (Vec p : vs) {
          d = planeNormal.dot(p);

          if (d < dis.get()[0][i][0])
            dis.get()[0][i][0] = d;
          if (d > dis.get()[0][i][1])
            dis.get()[0][i][1] = d;
        }
      }
    }
  }
  bool intersectBox(const Ray &r) {
    double tNear = -1e20, tFar = 1e20;
    for (int i = 0; i < kNumPlaneSetNormals; ++i) {
      double tn = (dis.get()[0][i][0] - r.precomputedNumerator[i]) /
                  r.precomputeDenominator[i];
      double tf = (dis.get()[0][i][1] - r.precomputedNumerator[i]) /
                  r.precomputeDenominator[i];
      if (r.precomputeDenominator[i] < 0)
        std::swap(tn, tf);
      if (tn > tNear)
        tNear = tn;
      if (tf < tFar)
        tFar = tf;
      if (tNear > tFar)
        return false;
    }
    return true;
  }
  bool intersectTriangles(const Ray &r, double &outT, Vec &outX,
                          Triangle &outTri) {
    double d, inf = outT = 1e20;
    Vec p;

    for (std::list<Triangle>::iterator it = triangles.begin();
         it != triangles.end(); it++) {
      if (it->intersect(r.o, r.d, d, p)) {
        if (d < outT) {
          outT = d;
          outX = p;
          outTri = *it;
        }
      }
    }
    return outT < inf;
  }
};
Sphere sphereLights[] = {
    // Sphere(1., Vec(0, 50, -200), Vec(2, 3, 5.5) * 1000, Vec(), DIFF),
    // Sphere(1., Vec(-120, 100, -200), Vec(5, 3, 2.5) * 1500, Vec(), DIFF),
    // Sphere(1., Vec(-40, 200, -320), Vec(4, 5, 4.5) * 1000, Vec(), DIFF),
    // Sphere(1, Vec(-50, -30, 0), Vec(5.3, 5, 3.5) * 1500, Vec(), DIFF),
    Sphere(1, Vec(-50, 200, -10), Vec(5.3, 5, 3.5) * 15000, Vec(), DIFF),
};
std::list<MeshObject> objects;
int numLights = sizeof(sphereLights) / sizeof(Sphere);
inline double clamp(double x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
inline int toInt(double x) { return int(pow(clamp(x), 1 / 2.2) * 255 + .5); }
inline float toFloat(double x) { return pow(clamp(x), 1 / 2.2); }
inline bool intersectLight(const Ray &r, double &t, int &id) {
  double d, inf = t = 1e20;
  for (int i = numLights; i--;)
    if ((d = sphereLights[i].intersect(r)) && d < t) {
      t = d;
      id = i;
    }
  return t < inf;
}
inline bool intersectTriangles(const Ray &r, double &outT, Vec &outX,
                               Triangle &outTri) {
  double d, inf = outT = 1e20;
  Triangle tri;
  Vec p;
  for (std::list<MeshObject>::iterator it = objects.begin();
       it != objects.end(); it++) {
    if (it->intersectBox(r)) {
      if (it->intersectTriangles(r, d, p, tri)) {
        if (d < outT) {
          outT = d;
          outX = p;
          outTri = tri;
        }
      }
    }
  }
  return outT < inf;
}
Vec radiance(const Ray &ray, int depth, unsigned short *Xi, int E = 1) {
  double tTri, tLight; // distance to intersection
  int id = -1;         // id of intersected object
  Vec x, n, f, rawE;
  Triangle tri;
  Refl_t refl;
  bool intersectAny = false;

  if (intersectTriangles(ray, tTri, x, tri)) {
    n = tri.normal;
    f = tri.color;
    rawE = tri.e;
    refl = tri.refl;
    intersectAny = true;
  }
  // if (intersectLight(ray, tLight, id) && tLight <= tTri) {
  //   const Sphere &obj = sphereLights[id];
  //   x = ray.o + ray.d * tLight, n = (x - obj.p).norm(), f = obj.c, rawE =
  //   obj.e, refl = obj.refl; intersectAny = true;
  // }
  if (!intersectAny) {
    return Vec();
  }

  Vec nl = n.dot(ray.d) < 0 ? n : n * -1;

  double p = f.x > f.y && f.x > f.z ? f.x : f.y > f.z ? f.y : f.z; // max refl
  if (++depth > 5 || !p) {
    if (erand48(Xi) < p) {
      f = f * (1 / p);
    } else {
      return rawE * E;
    }
  }
  if (refl == DIFF) { // Ideal DIFFUSE reflection
    double r1 = 2 * M_PI * erand48(Xi), r2 = erand48(Xi), r2s = sqrt(r2);
    Vec w = nl, u = ((fabs(w.x) > .1 ? Vec(0, 1) : Vec(1)) % w).norm(),
        v = w % u;
    Vec d = (u * cos(r1) * r2s + v * sin(r1) * r2s + w * sqrt(1 - r2)).norm();
    // Loop over any lights
    Vec e;
    for (int i = 0; i < numLights; i++) {
      const Sphere &light = sphereLights[i];

      Vec sw = light.p - x,
          su = ((fabs(sw.x) > .1 ? Vec(0, 1) : Vec(1)) % sw).norm(),
          sv = sw % su;
      double cos_a_max =
          sqrt(1 - light.rad * light.rad / (x - light.p).dot(x - light.p));
      double eps1 = erand48(Xi), eps2 = erand48(Xi);
      double cos_a = 1 - eps1 + eps1 * cos_a_max;
      double sin_a = sqrt(1 - cos_a * cos_a);
      double phi = 2 * M_PI * eps2;
      Vec l = su * cos(phi) * sin_a + sv * sin(phi) * sin_a + sw * cos_a;
      l.norm();
      Ray shadowRay = Ray(x, l);
      tTri = 1e20;
      Vec xTri;
      intersectTriangles(shadowRay, tTri, xTri, tri);
      if (intersectLight(shadowRay, tLight, id) && id == i && tLight <= tTri) {
        // can access current light
        double omega = 2 * M_PI * (1 - cos_a_max);
        e = e + f.mult(light.e * l.dot(nl) * omega) * M_1_PI; // 1/pi for brdf
      }
    }
    return rawE * E + e + f.mult(radiance(Ray(x, d), depth, Xi, 0));
  } else if (refl == SPEC) { // Ideal SPECULAR reflection
    return rawE +
           f.mult(radiance(Ray(x, ray.d - n * 2 * n.dot(ray.d)), depth, Xi));
  } else {
    Ray reflRay(x, ray.d - n * 2 * n.dot(ray.d)); // Ideal dielectric REFRACTION
    bool into = n.dot(nl) > 0;                    // Ray from outside going in?
    double nc = 1, nt = 1.5, nnt = into ? nc / nt : nt / nc,
           ddn = ray.d.dot(nl), cos2t;
    if ((cos2t = 1 - nnt * nnt * (1 - ddn * ddn)) <
        0) // Total internal reflection
      return rawE + f.mult(radiance(reflRay, depth, Xi));

    Vec tdir = (ray.d * nnt - n * ((into ? 1 : -1) * (ddn * nnt + sqrt(cos2t))))
                   .norm();
    double a = nt - nc, b = nt + nc, R0 = a * a / (b * b),
           c = 1 - (into ? -ddn : tdir.dot(n));
    double Re = R0 + (1 - R0) * c * c * c * c * c, Tr = 1 - Re,
           P = .25 + .5 * Re, RP = Re / P, TP = Tr / (1 - P);
    Vec xxx = erand48(Xi) < P ? // Russian roulette
                  radiance(reflRay, depth, Xi) * RP
                              : radiance(Ray(x, tdir), depth, Xi) * TP;
    return rawE + f.mult(depth > 2
                             ? xxx
                             : radiance(reflRay, depth, Xi) * Re +
                                   radiance(Ray(x, tdir), depth, Xi) * Tr);
  }
}
// Vec globalColor = Vec(.2, .2, .3);
// Vec globalColor = Vec(248. / 255, 163. / 255, 189. / 255);
Vec modelColor = Vec(113. / 255, 94. / 255, 240. / 255);

void readObjFile(const char *name) {
  MeshObject obj = MeshObject(), bg = MeshObject();

  FILE *f = fopen(name, "r");
  Vec v = Vec(), vn = Vec(), vt = Vec();
  char c[255];
  int i = 0, v0i = 0, v1i = 0, v2i = 0, holder;
  std::list<Vec> vList, vnList, vtList;
  double minY = 1e20, maxZ = -1e20, offsetY = -50, offsetZ = -100;
  while ((i = fscanf(f, "v %lf %lf %lf\n", &v.x, &v.y, &v.z)) > 0) {
    i = fscanf(f, "vn %lf %lf %lf\n", &vn.x, &vn.y, &vn.z);
    i = fscanf(f, "vt %lf %lf\n", &vt.x, &vt.y);
    vList.push_back(Vec(v.x*5., 5.*v.y, -5.*v.z));
    // vnList.push_back(Vec(vn.x, vn.y, vn.z));
    if (v.y < minY)
      minY = v.y;
    if (v.z > maxZ)
      maxZ = v.z;
  }
  std::cout << "v res: " << vList.size() << std::endl;
  std::cout << "vn res: " << vnList.size() << std::endl;
  std::cout << "vt res: " << vtList.size() << std::endl;

  Vec vArr[vList.size()], vnArr[vnList.size()];
  i = 0;
  offsetY = offsetY - minY, offsetZ = offsetZ - maxZ;
  std::cout<<"maxZ: "<<maxZ<<"   offsetZ"<<offsetZ<<std::endl;
  for (Vec v : vList) {
    vArr[i++] = Vec(v.x, v.y + offsetY, v.z + offsetZ);
  }
  i = 0;
  for (Vec vn : vnList) {
    vnArr[i++] = vn;
  }
  i = fscanf(f, "g %s\n", c);
  std::cout << "g res: " << c << std::endl;

  // while ((i = fscanf(f, "f %d %d %d\n", &v0i, &v1i, &v2i)) > 0) {
  while ((i = fscanf(f, "f %d/%d/%d %d/%d/%d %d/%d/%d\n", &v0i, &holder,
                     &holder, &v1i, &holder, &holder, &v2i, &holder, &holder)) >
         0) {
    obj.triangles.push_back(Triangle(vArr[v0i - 1], vArr[v1i - 1],
                                     vArr[v2i - 1],
                                     Vec(modelColor.x + drand48() * .1 - .05,
                                         modelColor.y + drand48() * .1 - .05,
                                         modelColor.z + drand48() * .1 - .05),
                                     REFR));
  }
  std::cout << "f res: " << obj.triangles.size() << std::endl;
  Cubic box = Cubic(Vec(-700, -50, -500), 1500, 1000, 1000.0,
                    Vec(249. / 255, 237. / 255, 233. / 255), DIFF);
  bg.triangles.push_back(Triangle(box.v0, box.v5, box.v4, box.color, box.refl));
  bg.triangles.push_back(Triangle(box.v0, box.v1, box.v5, box.color, box.refl));
  bg.triangles.push_back(Triangle(box.v0, box.v1, box.v3, box.color, box.refl));
  bg.triangles.push_back(Triangle(box.v0, box.v3, box.v2, box.color, box.refl));

  objects.push_back(obj);
  objects.push_back(bg);
}
void mockScene() {
  MeshObject obj = MeshObject(), bg = MeshObject();

  Cubic box =
      Cubic(Vec(-500, -50.1, -400), 1000, 600, 1000.0, Vec(.9, .9, .9), DIFF);
  bg.triangles.push_back(Triangle(box.v0, box.v5, box.v4, box.color, box.refl));
  bg.triangles.push_back(Triangle(box.v0, box.v1, box.v5, box.color, box.refl));
  bg.triangles.push_back(Triangle(box.v0, box.v1, box.v3, box.color, box.refl));
  bg.triangles.push_back(Triangle(box.v0, box.v3, box.v2, box.color, box.refl));

  Cubic(Vec(10, -50, -50), 30.0, 20.0, 30.0, Vec(.3, .5, .9), REFR)
      .writeTriangles(&obj.triangles);
  Cubic(Vec(-50, -50, -200), 40.0, 70.0, 60.0, Vec(.9, .5, .7), SPEC)
      .writeTriangles(&obj.triangles);
  Cubic(Vec(-120, -50, -200), 32.0, 40.0, 60.0, Vec(.7, .3, .4), REFR)
      .writeTriangles(&obj.triangles);
  Cubic(Vec(-45, -50, -60), 30.0, 30.0, 30.0, Vec(.4, .9, .6), REFR)
      .writeTriangles(&obj.triangles);

  objects.push_back(obj);
  objects.push_back(bg);
}
int main(int argc, char *argv[]) {
  int w = 1920 / 4, h = w * .75,
      samps = argc == 2 ? atoi(argv[1]) : 1;             // # samples
  Ray cam(Vec(150, 70, 235.5), Vec(-.39, 0, -1).norm()); // cam pos, dir
  Vec cx = Vec(w * .8 / h), cy = (cx % cam.d).norm() * .8, r,
      *c = new Vec[w * h];
  // mockScene();
  readObjFile("cube.obj");
  // readObjFile("537_lulu_faerie_classic.obj");
  for (MeshObject obj : objects) {
    obj.computeBounds();
  }
  std::cout << "\n" << w << "*" << h << std::endl;
#pragma omp parallel for schedule(dynamic, 1) private(r) // OpenMP
  for (int y = 0; y < h; y++) {                          // Loop over image rows
    fprintf(stderr, "\rRendering (%d spp) %5.2f%%", samps, 100. * y / (h - 1));
    for (unsigned short x = 0,
                        Xi[3] = {0, 0, static_cast<unsigned short>(y * y * y)};
         x < w; x++) // Loop cols
      for (int sy = 0, i = (h - y - 1) * w + x; sy < 1;
           sy++)                                    // 2x2 subpixel rows
        for (int sx = 0; sx < 1; sx++, r = Vec()) { // 2x2 subpixel cols
          for (int s = 0; s < samps; s++) {
            double ddx = (0. + x) / w - .5;
            double ddy = (0. + y) / h - .5;
            Vec d = cx * ddx + cy * ddy + cam.d;
            r = r +
                radiance(Ray(cam.o + d * 140, d.norm()), 0, Xi) * (1. / samps);
          } // Camera rays are pushed ^^^^^ forward to start in interior
          c[i] = c[i] + Vec(clamp(r.x), clamp(r.y), clamp(r.z)) * 1.;
        }
  }
  FILE *f = fopen("image.pfm", "w"); // Write image to PPM file.
  fprintf(f, "PF\n%d %d\n-1.0\n", w, h);
  for (int i = w * h - 1; i >= 0; i--) {
    float fs[] = {toFloat(c[i].x), toFloat(c[i].y), toFloat(c[i].z)};
    fwrite(fs, sizeof(float), 3, f);
  }
  std::cout << "\ntotal check: " << count << std::endl;
}