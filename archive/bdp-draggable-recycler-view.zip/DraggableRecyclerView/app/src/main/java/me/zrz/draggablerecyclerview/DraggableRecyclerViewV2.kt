package me.zrz.draggablerecyclerview

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.MotionEvent.*
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.min

/**
 * 使用：
 * RecyclerView的高度直接设置为允许的最大列表高度。设置draggableVerticalDistance即可。
 */
class DraggableRecyclerViewV2 : RecyclerView {
    constructor(context: Context) : super(context) {}
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {}
    constructor(context: Context, attrs: AttributeSet?, defStyle: Int) : super(
        context,
        attrs,
        defStyle
    )

    private var originalTop: Int = 0
    private var lastRawY: Float = 0f
    var e1Y: Float? = null

    var offsetTopAndBottomListener: OffsetTopAndBottomListener? = null
    var draggableVerticalDistance: Int = 0
        set(value) {
            field = value
            requestLayout()
            updateTranslationY(value.toFloat())
        }

    var handled = false

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        handled = false
        if (ev != null) {
            if (handleOffset(ev)) {
                handled = true
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onTouchEvent(ev: MotionEvent?): Boolean {
        if (!handled) {
            return super.onTouchEvent(ev)
        } else {
            return true
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        originalTop = top
        offsetTopAndBottomListener?.onChange()
    }

    private fun handleOffset(ev: MotionEvent): Boolean {
        val topDiff = translationY
        when (ev.action) {
            ACTION_DOWN -> {
                lastRawY = ev.rawY
                e1Y = ev.rawY
            }
            ACTION_MOVE -> {
                val rawDiffY = ev.rawY - lastRawY
                lastRawY = ev.rawY

                if (rawDiffY.toInt() < 0) {
                    //上滑
                    if (topDiff > 0) {//有上滑空间
                        updateTranslationY(translationY - min(abs(rawDiffY), topDiff))
                        return true
                    }
                } else {
                    //下滑
                    if (!canScrollUp() && topDiff < draggableVerticalDistance) {//有下滑空间
                        updateTranslationY(
                            translationY + min(
                                rawDiffY,
                                abs(draggableVerticalDistance - topDiff)
                            )
                        )
                        return true
                    }
                }
            }
            ACTION_UP -> {
                if (topDiff > 0 || (!canScrollUp() && topDiff < draggableVerticalDistance)) {
                    return true
                }
            }
        }
        return false
    }



    private fun updateTranslationY(ty: Float) {
        translationY = ty
        offsetTopAndBottomListener?.onChange()
    }

    private fun canScrollUp() = canScrollVertically(-1)

    interface OffsetTopAndBottomListener {
        fun onChange()
    }
}