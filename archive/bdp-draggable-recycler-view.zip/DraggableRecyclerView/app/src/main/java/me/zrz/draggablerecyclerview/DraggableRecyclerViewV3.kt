package me.zrz.draggablerecyclerview

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.MotionEvent.*
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.min

/**
 * 使用：
 * RecyclerView的高度直接设置为允许的最大列表高度。设置draggableVerticalDistance即可。
 */
class DraggableRecyclerViewV3 : RecyclerView {
    constructor(context: Context) : super(context) {}
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {}
    constructor(context: Context, attrs: AttributeSet?, defStyle: Int) : super(
        context,
        attrs,
        defStyle
    )

    private val gestureDetector =
        GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent?): Boolean {
                if (e != null) {
                    lastRawY = e.rawY
                    e1Y = e.rawY
                }
                return false
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent?,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (e2 != null) {
                    val rawDiffY = e2.rawY - lastRawY
                    lastRawY = e2.rawY

                    if (rawDiffY.toInt() < 0) {
                        //上滑
                        if (translationY > 0) {//有上滑空间
                            updateTranslationY(translationY - min(abs(rawDiffY), translationY))
                            return true
                        }
                    } else {
                        //下滑
                        if (!canScrollUp() && translationY < draggableVerticalDistance) {//有下滑空间
                            updateTranslationY(
                                translationY + min(
                                    rawDiffY,
                                    abs(draggableVerticalDistance - translationY)
                                )
                            )
                            return true
                        }
                    }
                }
                return false
            }
        })

    private var originalTop: Int = 0
    private var lastRawY: Float = 0f
    var e1Y: Float? = null

    var offsetTopAndBottomListener: OffsetTopAndBottomListener? = null
    var draggableVerticalDistance: Int = 0
        set(value) {
            field = value
            requestLayout()
            updateTranslationY(value.toFloat())
        }

    var handled = false

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        handled = false
        if (ev != null) {
            if (gestureDetector.onTouchEvent(ev)) {
                handled = true
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onTouchEvent(ev: MotionEvent?): Boolean {
        if (!handled) {
            return super.onTouchEvent(ev)
        } else {
            return true
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        originalTop = top
        offsetTopAndBottomListener?.onChange()
    }

    private fun updateTranslationY(ty: Float) {
        translationY = ty
        offsetTopAndBottomListener?.onChange()
    }

    private fun canScrollUp() = canScrollVertically(-1)

    interface OffsetTopAndBottomListener {
        fun onChange()
    }
}