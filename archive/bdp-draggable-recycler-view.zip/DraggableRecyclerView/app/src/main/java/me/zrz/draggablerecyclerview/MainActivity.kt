package me.zrz.draggablerecyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Layout
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.poi_item.view.*

class MainActivity : AppCompatActivity() {

    private val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return object : RecyclerView.ViewHolder(
                LayoutInflater.from(parent.context).inflate(R.layout.poi_item, parent, false)
            ) {}
        }

        override fun getItemCount(): Int {
            return 100
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            holder.itemView.poiName.text = "pos: $position"
            holder.itemView.setOnClickListener {v->
                Log.v("dd", "onClick${v}")
            }
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        draggableRv.adapter = adapter
        draggableRv.draggableVerticalDistance = 500
        draggableRv.offsetTopAndBottomListener =
            object : DraggableRecyclerViewV3.OffsetTopAndBottomListener {
                override fun onChange() {
                    floatTv.translationY = draggableRv.translationY
                }
            }
    }
}