package org.tu.android.core

abstract class TuLayer {
    abstract fun onDraw(canvas: TuCanvas, paint: TuPaint)
    fun draw() {
    }
}