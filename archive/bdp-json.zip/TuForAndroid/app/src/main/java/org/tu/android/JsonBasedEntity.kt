package org.tu.android

import org.json.JSONObject
import kotlin.properties.ReadOnlyProperty
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

open class JsonBasedEntity(val jsonObject: JSONObject) {
    /**
     * 会先进行约束检查，如果不满足，会在构造此对象时候直接抛出异常。后续get不会有更多耗时
     */
    fun <T> jsonField(jsonPath: String,
                      defaultValue: T? = null,
                      customInit: ((jsonValue: T) -> T)? = null) = JsonFieldImpl(jsonObject, jsonPath, defaultValue, customInit)

    /**
     * 不指定jsonPath而是以property.name作为jsonPath的方式
     */
    fun <T> jsonField(defaultValue: T? = null,
                      customInit: ((jsonValue: T) -> T)? = null) = JsonFieldDelegateProvider(jsonObject, defaultValue, customInit)

    fun hasJsonField(jsonPath: String) = object : ReadOnlyProperty<JsonBasedEntity, Boolean> {
        override fun getValue(thisRef: JsonBasedEntity, property: KProperty<*>): Boolean = jsonObject.has(jsonPath)
    }

    /**
     * 不指定jsonPath而是以property.name作为jsonPath的方式，如果属性名字开头是has，会自动删除并第四个字符改为小写。
     */
    fun hasJsonField() = HasJsonFieldDelegateProvider(jsonObject)

    class JsonFieldImpl<T>(jsonObject: JSONObject, jsonPath: String, defaultValue: T?, customInit: ((jsonValue: T) -> T)?) : ReadWriteProperty<JsonBasedEntity, T> {
        private var value: T

        init {
            var jsonValue = jsonObject.opt(jsonPath) as T
            if (jsonValue == null && defaultValue != null) {
                jsonValue = defaultValue
            }
            value = customInit?.invoke(jsonValue) ?: jsonValue
        }

        override fun getValue(thisRef: JsonBasedEntity, property: KProperty<*>): T = value
        override fun setValue(thisRef: JsonBasedEntity, property: KProperty<*>, value: T) {
            this.value = value
        }
    }

    class JsonFieldDelegateProvider<T>(private val jsonObject: JSONObject,
                                       private val defaultValue: T?,
                                       private val customInit: ((jsonValue: T) -> T)?) {
        operator fun provideDelegate(thisRef: JsonBasedEntity, property: KProperty<*>) = JsonFieldImpl(jsonObject, property.name, defaultValue, customInit)
    }

    class HasJsonFieldDelegateProvider(private val jsonObject: JSONObject) {
        operator fun provideDelegate(thisRef: JsonBasedEntity, property: KProperty<*>) =
                object : ReadOnlyProperty<JsonBasedEntity, Boolean> {
                    val propertyName = property.name
                    val jsonPath = if (propertyName.startsWith("has")) propertyName.substring(3).decapitalize() else propertyName
                    override fun getValue(thisRef: JsonBasedEntity, property: KProperty<*>): Boolean = jsonObject.has(jsonPath)
                }
    }
}