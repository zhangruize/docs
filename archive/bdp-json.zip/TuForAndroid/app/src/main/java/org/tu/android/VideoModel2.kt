package org.tu.android

import org.json.JSONObject
import org.tu.android.JsonBasedEntity

class VideoModel2(jsonObject: JSONObject) : JsonBasedEntity(jsonObject) {
    val filePath: String? by jsonField(customInit = {
        // some custom process
        it
    })
    var hide: Boolean? by jsonField()

    var needEvent: Boolean? by jsonField("needEvent", false)
    var autoplay: Boolean? by jsonField(defaultValue = false)
    val hasPoster: Boolean by hasJsonField()
    var poster: String? by jsonField()
    var controls: Boolean by jsonField(defaultValue = true)
    var live: Boolean? by jsonField(defaultValue = false)
    var muted: Boolean? by jsonField(defaultValue = false)
    var showMuteBtn: Boolean? by jsonField(defaultValue = false)
    var loop: Boolean? by jsonField(defaultValue = false)
    var decrypt_token: String? by jsonField()
    var video_model: String? by jsonField()
    var encrypt_token: String? by jsonField()
    var video_id: String? by jsonField()
    var fetcher: String? by jsonField()
    var api_version: Int? by jsonField(defaultValue = 2)
    var auth_token: String? by jsonField()
    var resolution: String? by jsonField()
    var showFullscreenBtn: Boolean? by jsonField(defaultValue = true)
    var showPlayBtn: Boolean? by jsonField(defaultValue = true)
    var showPlaybackRateBtn: Boolean? by jsonField(defaultValue = false)
    var objectFit: String? by jsonField()
    var playBtnPosition: String? by jsonField()

}