package org.tu.android.lib

import org.tu.android.core.TuCanvas
import org.tu.android.core.TuLayer
import org.tu.android.core.TuPaint

fun fontLayer(block: FontLayer.() -> Unit) {
    val fontLayer = FontLayer()
    fontLayer.block()
}

class FontLayer : TuLayer() {
    override fun onDraw(canvas: TuCanvas, paint: TuPaint) {

    }

}