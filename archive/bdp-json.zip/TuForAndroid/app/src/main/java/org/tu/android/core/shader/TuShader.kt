package org.tu.android.core.shader

open class TuShader {
}