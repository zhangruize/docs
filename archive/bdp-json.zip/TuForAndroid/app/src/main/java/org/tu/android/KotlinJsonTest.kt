package org.tu.android

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class KotlinJsonTest : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    fun startTest(view: View) {

        val jo = JSONObject()
        jo.put("filePath", "f")
        jo.put("hide", true)
        jo.put("needEvent", false)
        jo.put("autoplay", false)
        jo.put("poster", "po")
        jo.put("controls", "co")
        jo.put("live", "li")
        jo.put("muted", "mu")
        jo.put("showMuteBtn", false)
        jo.put("loop", true)
        jo.put("decrypt_token", "de")
        jo.put("video_model", "vi")
        jo.put("encrypt_token", "en")
        jo.put("video_id", "vi")
        jo.put("fetcher", "fe")
        jo.put("api_version", 20)
        jo.put("auth_token", "au")
        jo.put("resolution", "re")
        jo.put("showFullscreenBtn", false)
        jo.put("showPlayBtn", false)
        jo.put("showPlaybackRateBtn", true)
        jo.put("objectFit", "ob")
        jo.put("playBtnPosition", "pl")

        var start = System.currentTimeMillis()
        for (i in 0..10) {
            val p1 = System.currentTimeMillis()
            val vm = JsonParse(jo)
            Log.e("zrz", "opt: " + (System.currentTimeMillis() - p1))
        }


        Log.e("zrz", "opt all: " + (System.currentTimeMillis() - start))

        start = System.currentTimeMillis()

        for (i in 0..10) {
            val p1 = System.currentTimeMillis()
            val vm = VideoModel2(jo)
            Log.e("zrz", ("delegate: " + (System.currentTimeMillis() - p1)))
        }

        Log.e("zrz", "de all :" + (System.currentTimeMillis() - start))
    }

    class JsonParse(val raw: JSONObject) {
        val jo = JSONObject()
        val v1 = jo.optString("filePath", "f")
        val v2 = jo.optBoolean("hide", true)
        val v3 = jo.optBoolean("needEvent", false)
        val v4 = jo.optBoolean("autoplay", false)
        val v5 = jo.optString("poster", "po")
        val v6 = jo.optString("controls", "co")
        val v7 = jo.optString("live", "li")
        val v8 = jo.optString("muted", "mu")
        val v9 = jo.optBoolean("showMuteBtn", false)
        val v10 = jo.optBoolean("loop", true)
        val v11 = jo.optString("decrypt_token", "de")
        val v12 = jo.optString("video_model", "vi")
        val v13 = jo.optString("encrypt_token", "en")
        val v14 = jo.optString("video_id", "vi")
        val v15 = jo.optString("fetcher", "fe")
        val v16 = jo.optInt("api_version", 20)
        val v17 = jo.optString("auth_token", "au")
        val v18 = jo.optString("resolution", "re")
        val v19 = jo.optBoolean("showFullscreenBtn", false)
        val v20 = jo.optBoolean("showPlayBtn", false)
        val v21 = jo.optBoolean("showPlaybackRateBtn", true)
        val v22 = jo.optString("objectFit", "ob")
        val v23 = jo.optString("playBtnPosition", "pl")

    }
}