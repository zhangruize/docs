package org.tu.android.core.shader

class SolidShader : TuShader() {
    var color: Int = 0xff000000.toInt()
}