package org.tu.android.core

class TuPaint {
}