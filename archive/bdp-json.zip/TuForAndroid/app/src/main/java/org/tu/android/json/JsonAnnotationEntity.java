package org.tu.android.json;

import org.tu.jsonfieldannotation.HasJsonField;
import org.tu.jsonfieldannotation.JsonField;

public class JsonAnnotationEntity {
    @JsonField
    final String f1 = "fff1";

    @HasJsonField
    boolean hasF1 = true;

    @JsonField
    BasicStyle style;

    static class BasicStyle {
        @JsonField
        final int top = 999;

    }

}
