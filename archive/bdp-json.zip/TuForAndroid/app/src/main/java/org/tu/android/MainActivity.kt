package org.tu.android

import android.app.ActivityManager
import android.content.Context
import android.graphics.Canvas
import android.os.Bundle
import android.os.Looper
import android.os.PersistableBundle
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.Dispatchers

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val wms = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            getSystemService(WindowManager::class.java)
        } else {
        }
        val iv = findViewById<ImageView>(R.id.testImage)
        iv.postDelayed({ iv.setImageDrawable(resources.getDrawable(R.drawable.logo)) }, 1000)
        iv.postDelayed({ iv.setColorFilter(0xff000000.toInt()) }, 2000)
        iv.postDelayed({ iv.setImageDrawable(resources.getDrawable(R.drawable.logo2)) }, 3000)
        iv.postDelayed({
            println("sf" + iv)
        }, 4000)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val a = getSystemServiceName(ActivityManager::class.java)
            Dispatchers.Default
        } else {
        }

        (iv.parent as ViewGroup).addView(TestView(this, null, 0).also {
            it.setOnClickListener {
                println("sf")
            }
        })
    }


    override fun onPostCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onPostCreate(savedInstanceState, persistentState)
    }

    override fun onStart() {
        super.onStart()
    }

    class TestView @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
    ) : View(context, attrs, defStyleAttr) {
        override fun onDraw(canvas: Canvas?) {
            super.onDraw(canvas)
        }

        override fun dispatchTouchEvent(event: MotionEvent?): Boolean {
            return super.dispatchTouchEvent(event)
        }
    }
}