package org.tu.android

import org.tu.android.core.shader.SolidShader
import org.tu.android.core.tu
import org.tu.android.lib.fontLayer
import org.tu.android.lib.shapeLayer

class TuTest {

    fun test() {
        tu {
            mainCanvas {
                size(1000, 600)
                layerGroup {
                    layers + shapeLayer {
                        rect(20, 20, canvasWidth - 20, canvasHeight - 20, SolidShader())
                    }
                    layers + fontLayer {

                    }
                    // note: if we don't plus this layer to 'layers', it will not be display.
                    val layerWillNotDisplay = layerGroup {

                    }
                    // dynamically create layer:
                    for (i in 0..3) {
                        layers + shapeLayer {
                            val margin = i * 10 + 20
                            rect(
                                margin,
                                margin,
                                canvasWidth - margin,
                                canvasHeight - margin,
                                SolidShader()
                            )
                        }
                    }
                }
            }
        }
    }
}