package org.tu.android.lib

import org.tu.android.core.TuCanvas
import org.tu.android.core.TuLayer
import org.tu.android.core.TuPaint
import org.tu.android.core.shader.TuShader

fun shapeLayer(block: ShapeLayer.() -> Unit) {
    val shapeLayer = ShapeLayer()
    shapeLayer.block()
}

class ShapeLayer : TuLayer() {
    fun rect(left: Int, top: Int, right: Int, bottom: Int, filler: TuShader) {

    }

    override fun onDraw(canvas: TuCanvas, paint: TuPaint) {

    }
}