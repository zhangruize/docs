package org.tu.android.core

fun tu(block: Tu.() -> Unit) {
    val tu = Tu()
    tu.block()
}

class Tu {
    fun mainCanvas(block: TuCanvas.() -> Unit) {
        val tuCanvas = TuCanvas()
        tuCanvas.block()
    }
}
