package org.tu.android.core

fun layerGroup(block: TuLayerGroup.() -> Unit) {
    val layerGroup = TuLayerGroup()
    layerGroup.block()
}

class TuLayerGroup : TuLayer() {
    val layers = ArrayList<TuLayer>()

    operator fun ArrayList<TuLayer>.plus(e: TuLayer) {
        addInner(e)
    }

    operator fun ArrayList<TuLayer>.minus(e: TuLayer) {
        remove(e)
    }


    fun add(e: TuLayer) {
        addInner(e)
    }

    fun clear() {
        layers.clear()
    }


    private fun addInner(e: TuLayer) {
        layers.add(e)
    }

    private fun removeInner(e: TuLayer) {
        layers.remove(e)
    }

    override fun onDraw(canvas: TuCanvas, paint: TuPaint) {
        layers.forEach {
            it.onDraw(canvas, paint)
        }
    }
}