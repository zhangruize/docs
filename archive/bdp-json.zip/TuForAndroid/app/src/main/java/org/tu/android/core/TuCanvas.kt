package org.tu.android.core

class TuCanvas {
    val group = TuLayerGroup()
    var canvasWidth: Int = 1000
        private set
    var canvasHeight: Int = 1000
        private set

    fun layerGroup(block: TuLayerGroup.() -> Unit) {
        group.block()

    }

    fun size(width: Int, height: Int) {
        canvasWidth = width
        canvasHeight = height
    }

    fun doFrame() {
        group.draw()
    }
}