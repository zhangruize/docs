package org.tu.android;

import org.tu.android.json.JsonAnnotationEntity;
import org.tu.jsonfieldannotation.JsonField;

public class AnotherJsonTestEntity {
    @JsonField
    public boolean hide = false;

    @JsonField
    public JsonAnnotationEntity entity;
}
