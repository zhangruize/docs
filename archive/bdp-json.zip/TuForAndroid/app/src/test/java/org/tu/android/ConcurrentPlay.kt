package org.tu.android

import kotlinx.coroutines.*
import org.junit.Test

@Test
fun main() = runBlocking {
    launch { // launch a new coroutine and continue
        Throwable().printStackTrace()
        delay(1000L) // non-blocking delay for 1 second (default time unit is ms)
        println("World!") // print after delay
    }
        Throwable().printStackTrace()
    println("Hello") // main coroutine continues while a previous one is delayed
}

fun pAsync() = GlobalScope.async{

}