package org.tu.android;


import org.junit.Test;

public class TestC {

    @Test
    public void p(){
    }
}


class A {
    static {
        System.out.println("a");
    }
    int i = 1;

    {
        System.out.println("a " + i);
    }

    A() {
        System.out.println(i);
        i = 10;
        System.out.println(i);
    }

    {
        System.out.println("b " + i);
    }
}

class B extends A {
    {
        System.out.println("c " + i);
    }

    B() {
        System.out.println(i);
        i = 100;
        System.out.println(i);
    }

    {
        System.out.println("d " + i);
    }
    static {
        System.out.println("b");
    }
}
