package org.tu.android;

public class Tree {
    @org.junit.Test
    public void test() {
        int k = 3;
        Node head = createList(1, 2, 3, 4, 6, 7, 8);


        Node cur = head;
        Node last = head;
        Node prev;
        Node result = null;
        int count = 1;
        while (cur != null) {
            Node nn = cur.next;
            if (count >= k) {
                Node on = last.next;
                last.next = cur.next;
                prev = last;
                last = on;
                while (last != null) {
                    if (prev == cur) {
                        break;
                    }
                    Node temp = last.next;
                    last.next = prev;
                    prev = last;
                    last = temp;


                    if (result == null) {
                        result = cur;
                    }
                    count = 0;
                }
            }
            count++;
            cur = nn;
        }
        if (result == null) {
            result = head;
        }

        print(result);
    }

    public void print(Node n) {
        while (n != null) {
            System.out.print(n.value + ", ");
            n = n.next;
        }
    }

    public Node createList(int... values) {
        Node cur = new Node();
        Node head = cur;
        for (int value : values) {
            Node n = new Node();
            n.value = value;
            cur.next = n;
            cur = cur.next;
        }
        return head.next;
    }
}
// 1->2->3->4->5->6->7->8
// 3->2->1->6->5->4->7->8

// last,cur(1) 2,3...
// last(1),2,cur(3)... count == k
// last.next = cur.next 即 last(1)->4, 2->cur(3)->(4)
// 1->4, 2->1, 3->2, 即 3,2,1,4,5,6,7,8


class Node {
    Node next;
    Object value;
}
