package org.tu.android;

import org.junit.Test;

public class StringH {
    @Test
    public void p(){
        String a = new String("123").intern();
        String b = "123";
        System.out.println(a == b);
    }
}
