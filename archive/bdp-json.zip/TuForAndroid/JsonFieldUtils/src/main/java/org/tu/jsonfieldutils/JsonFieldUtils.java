package org.tu.jsonfieldutils;

import org.json.JSONObject;
import org.tu.jsonfieldannotation.JsonFieldConstraintException;

public class JsonFieldUtils {
    public static <T> T opt(JSONObject object, String path, Class<T> typeClass, T defaultValue) throws JsonFieldConstraintException {
        Object obj = object.opt(path);
        if (obj == null) {
            obj = defaultValue;
        }
        if (obj.getClass().equals(typeClass)) {
            return (T) obj;
        } else {
            throw new JsonFieldConstraintException("Can't cast " + obj.toString() + " to type: " + typeClass.getName());
        }
    }

    public static boolean has(JSONObject object, String path) {
        return object.has(path);
    }
}
