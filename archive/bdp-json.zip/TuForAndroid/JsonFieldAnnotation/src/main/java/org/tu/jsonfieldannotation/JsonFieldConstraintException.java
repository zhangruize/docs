package org.tu.jsonfieldannotation;

public class JsonFieldConstraintException extends Exception {
    public JsonFieldConstraintException(String s) {
        super(s);
    }
}
