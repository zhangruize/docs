package org.tu.lib;

import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.CodeBlock;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeSpec;

import org.tu.jsonfieldannotation.HasJsonField;
import org.tu.jsonfieldannotation.JsonField;
import org.tu.jsonfieldannotation.JsonFieldConstraintException;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.tools.Diagnostic;

@SupportedAnnotationTypes({"org.tu.jsonfieldannotation.JsonField", "org.tu.jsonfieldannotation.HasJsonField"})
@SupportedSourceVersion(SourceVersion.RELEASE_8)
public class JsonFieldProcessor extends AbstractProcessor {
    private static final String PACKAGE_JSON = "org.json";
    private static final String CLASS_JSON_OBJECT = "JSONObject";
    private static final String CLASS_JSON_EXCEPTION = "JSONException";
    private static final String PACKAGE_UTILS = "org.tu.jsonfieldutils";
    private static final String CLASS_UTILS = "JsonFieldUtils";

    private static final String FIELD_JSON = "jsonObject";
    private static final String FIELD_DATA = "data";
    private Messager messager;
    private final HashMap<String, EntityRecord> entityRecords = new HashMap<>();

    @Override
    public synchronized void init(ProcessingEnvironment processingEnvironment) {
        messager = processingEnvironment.getMessager();
        super.init(processingEnvironment);
    }

    @Override
    public boolean process(Set<? extends TypeElement> set, RoundEnvironment roundEnvironment) {
        if (set == null || set.isEmpty()) {
            return false;
        }
        for (Element element : roundEnvironment.getElementsAnnotatedWith(JsonField.class)) {
            processTargetElement(element);
        }
        for (Element element : roundEnvironment.getElementsAnnotatedWith(HasJsonField.class)) {
            processTargetElement(element);
        }
        try {
            generateBuilder();
        } catch (NullPointerException nullPointerException) {
            messager.printMessage(Diagnostic.Kind.ERROR, Arrays.toString(nullPointerException.getStackTrace()));
        }
        return false;
    }

    private void processTargetElement(Element element) {
        Element enclosingElement = element.getEnclosingElement();
        StringBuilder className = new StringBuilder();
        String simpleClassName = null;
        while (true) {
            if (enclosingElement.getKind() == ElementKind.PACKAGE) {
                String packageName = processingEnv.getElementUtils().getPackageOf(enclosingElement).getQualifiedName().toString();
                className.insert(0, packageName + ".").deleteCharAt(className.length() - 1);
                putRecord(className.toString(), packageName, simpleClassName, element);
                break;
            } else if (enclosingElement.getKind() == ElementKind.CLASS) {
                if (simpleClassName == null) {
                    simpleClassName = enclosingElement.getSimpleName().toString();
                }
                className.insert(0, enclosingElement.getSimpleName() + ".");
            } else {
                messager.printMessage(Diagnostic.Kind.ERROR, "unexpected enclosing element: " + enclosingElement.toString());
            }
            enclosingElement = enclosingElement.getEnclosingElement();
        }
    }

    private void putRecord(String completeClassName, String packageName, String simpleName, Element targetElement) {
        EntityRecord entityRecord = entityRecords.get(completeClassName);
        if (entityRecord == null) {
            entityRecord = new EntityRecord(completeClassName, packageName, simpleName);
            entityRecords.put(completeClassName, entityRecord);
        }
        FieldRecord fieldRecord = new FieldRecord(targetElement);
        entityRecord.fields.add(fieldRecord);
    }

    private void generateBuilder() {
        Filer filer = processingEnv.getFiler();
        ClassName jsonObjectClassName = ClassName.get(PACKAGE_JSON, CLASS_JSON_OBJECT);
        ClassName jsonExceptionClassName = ClassName.get(PACKAGE_JSON, CLASS_JSON_EXCEPTION);
        ClassName utilsClassName = ClassName.get(PACKAGE_UTILS, CLASS_UTILS);
        for (EntityRecord value : entityRecords.values()) {
            try {
                ClassName entityClassName = ClassName.get(value.packageName, value.nestClassName());

                TypeSpec.Builder builderClass = TypeSpec
                        .classBuilder(value.simpleName + "Builder")
                        .addModifiers(Modifier.PUBLIC);

                builderClass.addField(entityClassName, FIELD_DATA, Modifier.PROTECTED);

                builderClass.addField(jsonObjectClassName, FIELD_JSON, Modifier.PROTECTED);

                CodeBlock.Builder toJsonCodes = CodeBlock.builder();
                toJsonCodes.addStatement("this.$L = $L", FIELD_DATA, FIELD_DATA);
                toJsonCodes.addStatement("$L = new $T()", FIELD_JSON, jsonObjectClassName);
                for (FieldRecord field : value.fields) {
                    switch (field.annotatedType) {
                        case FieldRecord.ANNOTATED_TYPE_JSON_FIELD:
                            EntityRecord typeRecord = entityRecords.get(field.className);
                            if (typeRecord != null) {
                                ClassName fieldClassName = ClassName.get(typeRecord.packageName, typeRecord.simpleName + "Builder");
                                toJsonCodes.addStatement("$L.put(\"$L\",new $T($L.$L).jsonObject())", FIELD_JSON, field.jsonPath, fieldClassName, FIELD_DATA, field.fieldName);
                            } else {
                                toJsonCodes.addStatement("$L.put(\"$L\", $L.$L)", FIELD_JSON, field.jsonPath, FIELD_DATA, field.fieldName);
                            }
                            break;
                    }
                }

                builderClass.addMethod(MethodSpec.constructorBuilder()
                        .addParameter(entityClassName, FIELD_DATA)
                        .addModifiers(Modifier.PUBLIC)
                        .addException(jsonExceptionClassName)
                        .addCode(toJsonCodes.build())
                        .build());

                CodeBlock.Builder optCodes = CodeBlock.builder();
                optCodes.addStatement("this.$L = $L", FIELD_JSON, FIELD_JSON);
                optCodes.addStatement("$L = new $T()", FIELD_DATA, entityClassName);
                for (FieldRecord field : value.fields) {
                    switch (field.annotatedType) {
                        case FieldRecord.ANNOTATED_TYPE_JSON_FIELD:
                            EntityRecord typeRecord = entityRecords.get(field.className);
                            if (typeRecord != null) {
                                ClassName fieldClassName = ClassName.get(typeRecord.packageName, typeRecord.simpleName + "Builder");
                                optCodes.addStatement("$L.$L = new $T($L.optJSONObject(\"$L\")).data()", FIELD_DATA, field.fieldName, fieldClassName, FIELD_JSON, field.jsonPath);
                            } else {
                                optCodes.addStatement("$L.$L = $T.opt($L, \"$L\", $L.class, $L)", FIELD_DATA, field.fieldName, utilsClassName, FIELD_JSON, field.jsonPath, field.className, "null");
                            }
                            break;
                        case FieldRecord.ANNOTATED_TYPE_HAS_JSON_FIELD:
                            optCodes.add("data.$L = $T.has($L, \"$L\");\n", field.fieldName, utilsClassName, FIELD_JSON, field.jsonPath);
                            break;
                    }
                }

                builderClass.addMethod(MethodSpec.constructorBuilder()
                        .addParameter(jsonObjectClassName, FIELD_JSON)
                        .addModifiers(Modifier.PUBLIC)
                        .addCode(optCodes.build())
                        .addException(JsonFieldConstraintException.class)
                        .build());

                builderClass.addMethod(MethodSpec.methodBuilder(FIELD_DATA)
                        .addModifiers(Modifier.PUBLIC)
                        .returns(entityClassName)
                        .addStatement("return $L", FIELD_DATA)
                        .build());

                builderClass.addMethod(MethodSpec.methodBuilder(FIELD_JSON)
                        .addModifiers(Modifier.PUBLIC)
                        .returns(jsonObjectClassName)
                        .addStatement("return $L", FIELD_JSON)
                        .build());

                JavaFile.builder(value.packageName, builderClass.build()).build().writeTo(filer);
            } catch (IOException ioException) {
                messager.printMessage(Diagnostic.Kind.ERROR, "exception: " + ioException);
            }
        }
    }
}
