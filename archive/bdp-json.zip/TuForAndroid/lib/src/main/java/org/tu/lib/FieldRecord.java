package org.tu.lib;

import org.tu.jsonfieldannotation.HasJsonField;
import org.tu.jsonfieldannotation.JsonField;

import javax.lang.model.element.Element;
import javax.lang.model.type.ArrayType;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.ErrorType;
import javax.lang.model.type.ExecutableType;
import javax.lang.model.type.IntersectionType;
import javax.lang.model.type.NoType;
import javax.lang.model.type.NullType;
import javax.lang.model.type.PrimitiveType;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.type.TypeVariable;
import javax.lang.model.type.UnionType;
import javax.lang.model.type.WildcardType;
import javax.lang.model.util.SimpleTypeVisitor7;
import javax.lang.model.util.SimpleTypeVisitor8;
import javax.lang.model.util.TypeKindVisitor6;
import javax.lang.model.util.TypeKindVisitor8;

public class FieldRecord {

    public final String fieldName;
    public final String jsonPath;
    public final String className;
    public int annotatedType = -1;

    public static final int ANNOTATED_TYPE_JSON_FIELD = 0;
    public static final int ANNOTATED_TYPE_HAS_JSON_FIELD = 1;

    public FieldRecord(Element element) {
        fieldName = element.getSimpleName().toString();
        jsonPath = element.getSimpleName().toString();
        className = element.asType().toString();
        JsonField jsonFieldAnnotation = element.getAnnotation(JsonField.class);
        if (jsonFieldAnnotation != null) {
            annotatedType = ANNOTATED_TYPE_JSON_FIELD;
            return;
        }
        HasJsonField hasJsonFieldAnnotation = element.getAnnotation(HasJsonField.class);
        if (hasJsonFieldAnnotation != null) {
            annotatedType = ANNOTATED_TYPE_HAS_JSON_FIELD;
            return;
        }
    }
}
