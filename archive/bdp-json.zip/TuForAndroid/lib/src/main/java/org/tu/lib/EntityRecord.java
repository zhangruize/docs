package org.tu.lib;

import java.util.ArrayList;

/**
 * EntityRecord
 */
public class EntityRecord {
    // eg: some.package.ParentClass.InnerClass
    // simpleName = InnerClass
    // className = some.package.ParentClass.InnerClass
    // packageName = some.package
    public String simpleName;
    public String className;
    public String packageName;
    public ArrayList<FieldRecord> fields = new ArrayList<>();

    public EntityRecord(String completeClassName, String packageName, String simpleName) {
        className = completeClassName;
        this.packageName = packageName;
        this.simpleName = simpleName;
    }

    public String nestClassName() {
        return className.substring(packageName.length() + 1);
    }
}
