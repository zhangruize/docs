package doclet;

import com.sun.javadoc.*;
import com.sun.tools.doclets.standard.Standard;

public class CustomDoclet extends Standard {
    public static boolean start(RootDoc root) {
        System.out.println("hello");
        String tagName = "mytag";
        writeContents(root.classes(), tagName);
        return true;
    }

    private static void writeContents(ClassDoc[] classes, String tagName) {
        for (int i = 0; i < classes.length; i++) {
            boolean classNamePrinted = false;
            System.out.println("hi: " + classes[i].name());
            MethodDoc[] methods = classes[i].methods();
            for (int j = 0; j < methods.length; j++) {
                Tag[] tags = methods[j].tags(tagName);
                if (tags.length > 0) {
                    if (!classNamePrinted) {
                        System.out.println("\n" + classes[i].name() + "\n");
                        classNamePrinted = true;
                    }
                    System.out.println(methods[j].name());
                    for (int k = 0; k < tags.length; k++) {
                        System.out.println("   " + tags[k].name() + ": "
                                + tags[k].text());
                    }
                }
            }
        }
    }


}
