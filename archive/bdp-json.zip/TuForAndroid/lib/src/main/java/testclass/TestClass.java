package testclass;

/**
 * @mytag Some dummy text.
 */
public class TestClass {

    /**
     * @mytag Some dummy text22.
     */
    public void play(){}
}
