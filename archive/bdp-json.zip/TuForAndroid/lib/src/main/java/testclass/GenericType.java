package testclass;

public class GenericType<T> {
    public <E> E play(E e) {
        return e;
    }

    public <E> T get(E e) {
        T help;
        help = (T) e;
        return help;
    }
}
