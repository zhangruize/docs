package org.tu.dokkacustomplugin;

public class CustomDokkaPlugin {
}